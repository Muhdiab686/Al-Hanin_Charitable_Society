<?php

namespace App\Http\Controllers\Api;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateDoctorClinicProfileRequest;
use App\Http\Requests\UpsertClinicStaffProfileRequest;
use App\Models\ClinicStaffProfile;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ClinicStaffController extends Controller
{
    public function index(): JsonResponse
    {
        $profiles = ClinicStaffProfile::query()
            ->with('user:id,name,email,role')
            ->latest('id')
            ->paginate(15);

        return response()->json($profiles);
    }

    public function candidates(): JsonResponse
    {
        $existingUserIds = ClinicStaffProfile::query()->pluck('user_id');

        $users = User::query()
            ->whereIn('role', [UserRole::Doctor->value, UserRole::Secretary->value])
            ->when($existingUserIds->isNotEmpty(), fn ($q) => $q->whereNotIn('id', $existingUserIds))
            ->orderBy('name')
            ->get(['id', 'name', 'email', 'role']);

        return response()->json(['candidates' => $users]);
    }

    public function upsert(UpsertClinicStaffProfileRequest $request): JsonResponse
    {
        $validated = $request->validated();
        $role = UserRole::from($validated['role']);

        if (! in_array($role, [UserRole::Doctor, UserRole::Secretary], true)) {
            abort(422, 'Clinic staff role must be doctor or secretary.');
        }

        $user = User::query()->findOrFail($validated['user_id']);

        $protectedRoles = [
            UserRole::Admin,
            UserRole::Accountant,
            UserRole::Storekeeper,
            UserRole::Donor,
            UserRole::Volunteer,
            UserRole::Beneficiary,
            UserRole::RecordingSecretary,
        ];

        if (in_array($user->role, $protectedRoles, true)) {
            throw ValidationException::withMessages([
                'user_id' => [__('This account cannot be assigned to clinic staff (protected system role). Create a dedicated doctor user from admin users.')],
            ]);
        }

        if (! in_array($user->role, [UserRole::Doctor, UserRole::Secretary], true)) {
            $user->forceFill(['role' => $role])->save();
            $user->syncRoles([$role->value]);
        }

        $profile = ClinicStaffProfile::query()->updateOrCreate(
            ['user_id' => $user->id],
            [
                'specialty' => $validated['specialty'] ?? null,
                'bio' => $validated['bio'] ?? null,
                'available_days' => $validated['available_days'] ?? null,
                'monthly_salary' => $validated['monthly_salary'],
                'consultation_fee' => $validated['consultation_fee'],
                'is_active' => $validated['is_active'],
            ]
        );

        return response()->json([
            'message' => __('Clinic staff profile saved successfully.'),
            'profile' => $profile->load('user:id,name,email,role'),
        ]);
    }

    public function showMine(Request $request): JsonResponse
    {
        $profile = ClinicStaffProfile::query()
            ->where('user_id', $request->user()->id)
            ->first();

        return response()->json([
            'profile' => $profile,
        ]);
    }

    public function updateMine(UpdateDoctorClinicProfileRequest $request): JsonResponse
    {
        $validated = $request->validated();

        $profile = ClinicStaffProfile::query()->firstOrNew([
            'user_id' => $request->user()->id,
        ]);

        $profile->forceFill([
            'specialty' => $validated['specialty'],
            'bio' => $validated['bio'] ?? null,
            'available_days' => $validated['available_days'],
            'consultation_fee' => $validated['consultation_fee'],
            'is_active' => true,
            'monthly_salary' => $profile->exists ? $profile->monthly_salary : 0,
        ])->save();

        return response()->json([
            'message' => __('Doctor profile updated successfully.'),
            'profile' => $profile->fresh()->load('user:id,name,email,role'),
        ]);
    }
}
